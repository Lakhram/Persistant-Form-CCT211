#Persistent Form Project 2 CCT211 Brandon Lakhram
'''In the final version of this application ideally the code section will only take
#the specified numbers for the parts codes'''

'''The overall design of the project has changed in regards to the original proposal.
Taking note from the feedback given, the original idea represented more of a website interface
rather than a business system. I have altered it to be a parts inventory system instead as that
resembles more to what the project guidelines are asking.'''

import sqlite3
from tkinter import *
from tkinter import ttk
import tkinter as tk
from PIL import Image, ImageTk

class MainApplication:
    def __init__(self, master):
        self.master = master
        self.master.title("Car Inventory Application")
        self.master.geometry("1020x300")

        def reverse(tuples):
            new_tup = tuples[::-1]
            return new_tup

        def insert(code, item, quantity, price):
            conn = sqlite3.connect("data.db")
            cursor = conn.cursor()
            cursor.execute("""CREATE TABLE IF NOT EXISTS
            inventory(itemCode TEXT, itemName TEXT, itemQuantity TEXT, itemPrice TEXT)
            """)
            cursor.execute(
                "INSERT INTO inventory VALUES('" + str(code) + "','" + str(item) + "','" + str(quantity) + "','" + str(
                    price) + "')")
            conn.commit()

        def delete(data):
            conn = sqlite3.connect("data.db")
            cursor = conn.cursor()
            cursor.execute("""CREATE TABLE IF NOT EXISTS
            inventory(itemCode TEXT, itemName TEXT, itemQuantity TEXT, itemPrice TEXT)
            """)
            cursor.execute("DELETE FROM inventory WHERE itemCode='" + str(data) + "'")
            conn.commit()

        def update(code, item, quantity, price, itemCode):
            conn = sqlite3.connect("data.db")
            cursor = conn.cursor()
            cursor.execute("""CREATE TABLE IF NOT EXISTS
            inventory(itemCode TEXT, itemName TEXT, itemQuantity TEXT, itemPrice TEXT)
            """)
            cursor.execute(
                "UPDATE inventory SET itemCode='" + str(code) + "',itemName='" + str(item) + "',itemQuantity='" + str(
                    quantity) + "',itemPrice='" + str(price) + "' WHERE itemCode='" + str(item) + "'")
            conn.commit()

        def read():
            conn = sqlite3.connect("data.db")
            cursor = conn.cursor()
            cursor.execute("""CREATE TABLE IF NOT EXISTS
            inventory(itemCode TEXT, itemName TEXT, itemQuantity TEXT, itemPrice TEXT)
            """)
            cursor.execute("SELECT * FROM inventory")
            results = cursor.fetchall()
            conn.commit()
            return results

        def insert_data():
            itemCode = str(code_entry.get())
            itemName = str(item_entry.get())
            itemQuantity = str(quantity_entry.get())
            itemPrice = str(price_entry.get())

            if itemCode == "" or itemCode == " ":
                print("Error with code")
            if itemName == "" or itemName == " ":
                print("Error with item")
            if itemQuantity == "" or itemQuantity == " ":
                print("Error with quantity")
            if itemPrice == "" or itemPrice == " ":
                print("Error with price")

            else:
                insert(str(itemCode), str(itemName), str(itemQuantity), str(itemPrice))

            for data in main_tree.get_children():
                main_tree.delete(data)

            for result in reverse(read()):
                main_tree.insert(parent='', index='end', iid=result, text="",
                                 values=(result), tag="orow")

            main_tree.tag_configure('orow', background='GREY')
            main_tree.grid(row=1, column=5, columnspan=4, rowspan=4,
                           padx=5, pady=5)

        def delete_data():
            selected_item = main_tree.selection()[0]
            deleteData = str(main_tree.item(selected_item)['values'][0])
            delete(deleteData)

            for data in main_tree.get_children():
                main_tree.delete(data)

            for result in reverse(read()):
                main_tree.insert(parent='', index='end', iid=result,
                                 text="", values=(result), tag="orow")

            main_tree.tag_configure('orow', background='GREY')
            main_tree.grid(row=1, column=5, columnspan=4, rowspan=4,
                           padx=5, pady=5)

        def update_data():
            selected_item = main_tree.selection()[0]
            update_name = str(main_tree.item(selected_item)['values'][0])
            update(code_entry.get(), item_entry.get(),
                   quantity_entry.get(), price_entry.get(), update_name)

            for data in main_tree.get_children():
                main_tree.delete(data)

            for result in reverse(read()):
                main_tree.insert(parent='', index='end', iid=result,
                                 text="", values=(result), tag="orow")

            main_tree.tag_configure('orow', background='GREY')
            main_tree.grid(row=1, column=5, columnspan=4, rowspan=4,
                           padx=5, pady=5)

        #Function responsible for creating new window when button is clicked
        def external_window():
            #Creating a new window
            new_window= tk.Toplevel(root)

            # Two frames
            frame1 = tk.Frame(new_window, bg="grey", width=400, height=400)
            frame2 = tk.Frame(new_window, bg="grey", width=400, height=400)

            frame1.grid(row=0, column=0, padx=5, pady=5)
            frame2.grid(row=0, column=1, padx=5, pady=5)

            # Creating Images with Labels to go into frame
            image1 = Image.open("newbrakes.png")
            photo1 = ImageTk.PhotoImage(image1)
            label1 = tk.Label(frame1, image=photo1, text="Brakes and Rotors")

            image2 = Image.open("enginenew.png")
            photo2 = ImageTk.PhotoImage(image2)
            label2 = tk.Label(frame1, image=photo2, text="Engine Parts")

            image3 = Image.open("newexhaust.jpg")
            resize_exhaust = image3.resize((int(image1.width / 2), int(image1.height / 2)))
            resize_exhaust.save("resize_exhaust.png")
            photo3 = ImageTk.PhotoImage(resize_exhaust)
            label3 = tk.Label(frame2, image=photo3, text="Exhaust Parts")

            image4 = Image.open("newsuspension.jpg")
            resize_suspension = image4.resize((int(image1.width / 2), int(image1.height / 2)))
            resize_suspension.save("resize_exhaust.png")
            photo4 = ImageTk.PhotoImage(resize_suspension)
            label4 = tk.Label(frame2, image=photo4, text="Suspension Parts")

            # Creating Labels that correspond with codes for different parts of the suspension
            titleCode = tk.Label(frame2, text="List of all Part Codes")
            suspensionCode = tk.Label(frame2, text="Suspension : 4")
            exhaustCode = tk.Label(frame2, text="Exhaust : 3")
            engineCode = tk.Label(frame2, text="Engine : 2")
            brakesCode = tk.Label(frame2, text="Brakes and Calipers : 1")

            # placing labels with images
            label1.grid(row=1, column=0, padx=5, pady=5)
            label2.grid(row=2, column=0, padx=5, pady=5)
            label3.grid(row=1, column=0, padx=5, pady=5)
            label4.grid(row=2, column=0, padx=5, pady=5)

            # Placing labels for second frame
            titleCode.grid(row=0, column=0, padx=5, pady=5)
            suspensionCode.grid(row=1, column=0, padx=5, pady=5)
            exhaustCode.grid(row=2, column=0, padx=5, pady=5)
            engineCode.grid(row=3, column=0, padx=5, pady=5)
            brakesCode.grid(row=4, column=0, padx=5, pady=5)

            # App title that spans 5 rows, so it can lay atop of the entry fields

        inventorytitle = Label(root, text="Car Part Inventory System", font=("Sans Serif", 20), bd=2)
        inventorytitle.grid(row=0, column=0, columnspan=5, padx=10, pady=10)

        #Creating all the labels for the entry fields
        code_label = Label(root, text="Item Code:", font=("Sans Serif", 15), bd=2)
        item_label = Label(root, text="Item:", font=("Sans Serif", 15), bd=2)
        quantity_label = Label(root, text="Quantity:", font=("Sans Serif", 15), bd=2)
        price_label = Label(root, text="Price:", font=("Sans Serif", 15), bd=2)

        # Place labels using grid for better organization
        code_label.grid(row=1, column=0, padx=5, pady=5)
        item_label.grid(row=2, column=0, padx=5, pady=5)
        quantity_label.grid(row=3, column=0, padx=5, pady=5)
        price_label.grid(row=4, column=0, padx=5, pady=5)

        # Creating entry fields for information
        code_entry = Entry(root, width=20, bd=5, font=("Sans Serif", 15))
        item_entry = Entry(root, width=20, bd=5, font=("Sans Serif", 15))
        quantity_entry = Entry(root, width=20, bd=5, font=("Sans Serif", 15))
        price_entry = Entry(root, width=20, bd=5, font=("Sans Serif", 15))

        # Placing entry fields using grid to organize
        code_entry.grid(row=1, column=1, columnspan=3, padx=5, pady=5)
        item_entry.grid(row=2, column=1, columnspan=3, padx=5, pady=5)
        quantity_entry.grid(row=3, column=1, columnspan=3, padx=5, pady=5)
        price_entry.grid(row=4, column=1, columnspan=3, padx=5, pady=5)

        # Enter button
        enter_button = Button(root, text='Enter', width=5, bd=4,
                              font=("Sans Serif", 15),
                              command=insert_data)

        enter_button.grid(row=5, column=1, columnspan=1)

        # Update button
        update_button = Button(root, text='Update', width=5, bd=4,
                               font=("Sans Serif", 15),
                               command=update_data)

        update_button.grid(row=5, column=2, columnspan=1)

        # Delete button
        delete_button = Button(root, text='Delete', width=5, bd=4,
                               font=("Sans Serif", 15),
                               command=delete_data)

        delete_button.grid(row=5, column=3, columnspan=1)

        parts_button = tk.Button(root, text="Parts Codes",width=10, bd=3,
                               font=("Sans Serif", 15), command=external_window)
        parts_button.grid(row=5, column=4, columnspan=2)

        # def createTreeview():
        style = ttk.Style()
        style.configure('Treeview.Heading', font=("Sans Serif", 15))

        col = ("Code", "Item", "Quantity", "Price")
        main_tree = ttk.Treeview(root, height=5, show='headings', columns=col)

        main_tree.column("#0", width=0, stretch=NO)

        # Assigns the columns in the treeview
        main_tree.column("Code", anchor=W, width=100)
        main_tree.column("Item", anchor=W, width=200)
        main_tree.column("Quantity", anchor=W, width=150)
        main_tree.column("Price", anchor=W, width=150)

        # Sets the heading titles in the treeview
        main_tree.heading("Code", text="Code", anchor=W)
        main_tree.heading("Item", text="Item", anchor=W)
        main_tree.heading("Quantity", text="Quantity", anchor=W)
        main_tree.heading("Price", text="Price", anchor=W)

        # Placing the treeview beside the entry fields
        for data in main_tree.get_children():
            main_tree.delete(data)

        for result in reverse(read()):
            main_tree.insert(parent='', index='end', iid=0, text="", values=(result), tag="orow")

        main_tree.tag_configure('orow', background='GREY')
        main_tree.grid(row=1, column=5, columnspan=4, rowspan=4,
                       padx=5, pady=5)


if __name__ == "__main__":
    root = tk.Tk()
    app = MainApplication(root)
    root.mainloop()
